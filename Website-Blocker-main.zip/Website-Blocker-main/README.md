# Website-Blocker
This Python script is designed to block specific websites by modifying the system's hosts file on a Windows machine. It runs continuously, checking the current date and time to determine whether the specified websites should be blocked or unblocked. 
